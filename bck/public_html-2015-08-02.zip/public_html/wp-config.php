<?php
/**
 * Основные параметры WordPress.
 *
 * Этот файл содержит следующие параметры: настройки MySQL, префикс таблиц,
 * секретные ключи и ABSPATH. Дополнительную информацию можно найти на странице
 * {@link http://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Кодекса. Настройки MySQL можно узнать у хостинг-провайдера.
 *
 * Этот файл используется скриптом для создания wp-config.php в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать этот файл
 * с именем "wp-config.php" и заполнить значения вручную.
 *
 * @package WordPress
 */

// ** Параметры MySQL: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define('DB_NAME', 'mischag3_wp1');

/** Имя пользователя MySQL */
define('DB_USER', 'mischag3_wp1');

/** Пароль к базе данных MySQL */
define('DB_PASSWORD', 'jweJq67eW');

/** Имя сервера MySQL */
define('DB_HOST', 'localhost');

/** Кодировка базы данных для создания таблиц. */
define('DB_CHARSET', 'utf8mb4');

/** Схема сопоставления. Не меняйте, если не уверены. */
define('DB_COLLATE', '');

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу.
 * Можно сгенерировать их с помощью {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными. Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'UfuR~&ylPxJ`>t}P<A[/g(w;@h=N@S|ZDhL/gZozp)l6`k+$eVKdk5fq+h<[l-7c');
define('SECURE_AUTH_KEY',  '-gB^j_ge)4qE $$+tb <6uzebuG(DE?I%SfaA,-{9 <>1(X2/:?,9&L2w7Yq^Yw2');
define('LOGGED_IN_KEY',    'ucL0?3-0hmpF6Y&Os4tQo.5uMc)}(eR<lZaz]+2$C*qJ@;~wuqK;.~@Sg2?7Sw;Q');
define('NONCE_KEY',        '!<A=N+Au~ZTI+fE9HpWKti~*:gCTBmZ,+yE ]U7qBT=`YTVX6>HipQWu/U!QNyqK');
define('AUTH_SALT',        ',Pg8iTF|b2, fZT8~i le:|.IDfe`ApQ-ga?u=5;1r ,428#jRO>6c=V6R&I/_:U');
define('SECURE_AUTH_SALT', '{M>Rk<96|x=@U(i+ 3Xv5/gO+1b~+qILH*trZw@>-+E85[g7[,}QT09ID|oe/njI');
define('LOGGED_IN_SALT',   'sm:4*-Y3`^#]BhW[7b:&=dKH:%$^82h#| t5BdTV__>*c=_X-0_!OO`S+prwJF%|');
define('NONCE_SALT',       'RJ`d)7Eu{b_#Vx^zh+<$s`K,N3n&8m-]`Z<,6HFEC+0Y~TXm@qYXA|LHhv]64:6V');

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix  = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 */
define('WP_DEBUG', false);

/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Инициализирует переменные WordPress и подключает файлы. */
require_once(ABSPATH . 'wp-settings.php');
